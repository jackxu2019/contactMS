//
//  ContactPartInEngineDelegate.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Used to access all logics about contact.
/// And the loading method is designed as async
/// Notification occured to delegate in every state:
///   - The total count of contacts notified firstly. This can be used for pre rendering.
///   - Every contact information be fetched.
///   - Every avatar image is ready for use.
class ContactPartInEngine: NSObject {
    
    /// The delegate to handle all notifications of contact accessing.
    weak var delegate: ContactEnginDelegate?
    
    /// The result of querying contacts
    var contactsArray: NSMutableArray = NSMutableArray()
    
    /// The background color of avatar image
    /// No use for now, consider the engin may need redraw the image to build
    /// cornered and resized image, background color would be use.
    var avatarImgBgColor = UIColor.white
    
    private let queryQueue: DispatchQueue = DispatchQueue(label: "contactQuery")
    /// Load all contacts async
    /// Notification occured to delegate in every state:
    ///   - The total count of contacts notified firstly. This can be used for pre rendering.
    ///   - Every contact information be fetched.
    ///   - Every avatar image is ready for use.
    func loadAllContactsAsync() -> Void {
        
        if let delegate = self.delegate {
            delegate.contactPartInEngine?(contact: self, beginLoadWithTaskID: 0)
        }
        // Begin query in queryQueue async
        self.queryQueue.async {
            DispatchQueue.main.sync {
                self.contactsArray.removeAllObjects()
            }
            // Reand and anylize json file
            let path = Bundle.main.path(forResource: "contacts", ofType: "json")
            let url = URL(fileURLWithPath: path!)
            var array: NSArray?
            do{
                let data = try Data(contentsOf: url)
                let jsonData: Any = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                array = jsonData as? NSArray
            } catch _ as Error? {
                print("error in reading json")
            }
            if array == nil {
                return
            }
            var index = 0
            DispatchQueue.main.sync {
                for _ in 0..<array!.count {
                    let contact = ContactModel()
                    self.contactsArray.add(contact)
                }
                if let delegate = self.delegate {
                    delegate.contactPartInEngine?(contact: self, itemsCountReceived: array!.count)
                }
            }
            // Fill and access every contact model
            for dic in array! {
                DispatchQueue.main.sync {
                    self.fillContact(self.contactsArray.object(at: index) as! ContactModel, withDictionary: dic as! Dictionary)
                }
                
                if self.delegate != nil {
                    DispatchQueue.main.sync {
                        self.delegate?.contactPartInEngine?(contact: self, oneItemReceived: self.contactsArray[index] as! ContactModel, atIndex: index)
                    }
                }
                index = index + 1
            }
            // Access avatar image.
            index = 0;
            for contact in self.contactsArray {
                (contact as! ContactModel).avatarImg = self.loadAvatarImg(withName: (contact as! ContactModel).avatar_filename );
                if let delegate = self.delegate {
                    DispatchQueue.main.sync {
                        delegate.contactPartInEngine?(contact: self, avatarImgIsReady: (contact as! ContactModel).avatarImg, atIndex: index)
                    }
                }
                index = index + 1
            }
            // Finished this session
            if let delegate = self.delegate {
                DispatchQueue.main.sync {
                    delegate.contactPartInEngine?(contact: self, endedLoadWithTaskID: 0, succeed: true)
                }
            }
        }
    }
    
    /// loading a image to memery
    ///
    /// - Parameters:
    ///   - imgName:             Name of image to load.
    /// - Returns:               Loaded image.
    func loadAvatarImg(withName imgName: String?) -> UIImage? {
        if let name = imgName {
            return UIImage(named: name)
        }
        return nil
    }
    
    /// Fill datas of ContactModel with a dictionary
    ///
    /// - Parameters:
    ///   - contact:             ContactModel to fill.
    ///   - dic:                 Dictionary to read data from.
    func fillContact(_ contact: ContactModel, withDictionary dic: Dictionary<String, String>) ->Void {
        contact.avatar_filename = dic["avatar_filename"];
        contact.first_name = dic["first_name"];
        contact.introduction = dic["introduction"];
        contact.last_name = dic["last_name"];
        contact.title = dic["title"];
    }

}


