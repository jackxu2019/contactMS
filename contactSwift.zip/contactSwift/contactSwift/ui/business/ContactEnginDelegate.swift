//
//  ContactEnginDelegate.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import Foundation
import UIKit
/// Deleget of ContactPartInEngine.
/// It handles notifications below:
///   - The total count of contacts notified firstly. This can be used for pre rendering.
///   - Every contact information be fetched.
///   - Every avatar image is ready for use.
@objc protocol ContactEnginDelegate: class {
    
    /// Called when begin query contacts.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - taskId:         ID of this query session.
    @objc optional func contactPartInEngine(contact: ContactPartInEngine, beginLoadWithTaskID taskId: Int)
    
    /// Called when received the count of contact items.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - count:          Count of contact items.
    @objc optional func contactPartInEngine(contact: ContactPartInEngine, itemsCountReceived count: Int)
    
    /// Called when received a contact item(not include image).
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - model:          Received contact model.
    ///   - index:          Index of the received item in contacts.
    @objc optional func contactPartInEngine(contact: ContactPartInEngine, oneItemReceived model: ContactModel, atIndex index: Int)
    
    /// Called when an avatar image is ready.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - img:            Image of an avatar.
    ///   - index:          Index of the item in contacts.
    @objc optional func contactPartInEngine(contact: ContactPartInEngine, avatarImgIsReady img: UIImage?, atIndex index: Int)
    
    /// Called when finished a query contacts session.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - taskId:         ID of this query session.
    @objc optional func contactPartInEngine(contact: ContactPartInEngine, endedLoadWithTaskID taskId: Int, succeed: Bool)
}
