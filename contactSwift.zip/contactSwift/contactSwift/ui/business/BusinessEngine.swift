//
//  BusinessEngine.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// BusinessEngine is a sigleton class for all the logic business in this project,
/// may have many sub parts in it.
/// For now, a sub part Contact in it is responsible for all logic of accessing Contact.
/// It's quite simple to use：
/// ```
/// BusinessEngine.default().contact.loadAllContactsAsync()
/// ```
class BusinessEngine: NSObject {
    
    /// The sigleton instance
    static let `default` = BusinessEngine()
    
    /// The functional part to access all logics of contact
    var contact: ContactPartInEngine = ContactPartInEngine()
    
}
