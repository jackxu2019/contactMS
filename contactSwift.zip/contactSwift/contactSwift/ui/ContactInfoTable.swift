//
//  ContactInfoTable.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

private let REUSE_CELL_ID = "reuseID"

/// A table view to present contacts information.
/// It implemented the data source and tableView delegate inner.
/// User can simply build it by just giving an array of ContactModel.
class ContactInfoTable: UITableView, UITableViewDataSource, UITableViewDelegate {
    
    /// The data source of it.
    var dataSourceArray: NSMutableArray?
    
    /// Scroll helper to provode functions like snap and scrolling binder.
    private(set) var snapHelper: ScrollSnapHelper?
    
    /// The height of the table view cell.
    var cellHeight: CGFloat = 0
    
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        self.privateInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.privateInit()
    }
    
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0),
                   style: .plain)
        self.privateInit()
    }
    
    /// Private initialize method, can be invoked by all kindes of init
    private func privateInit()  {
        self.register(ContactInfoTableCell.self , forCellReuseIdentifier: REUSE_CELL_ID)
        self.dataSource = self;
        self.delegate = self;
        self.snapHelper = ScrollSnapHelper(step: 0)
        self.snapHelper!.attachScrollView(self)
        self.snapHelper!.snapOn = true
        self.snapHelper!.scrollDirection = .Vertical
        self.separatorStyle = .none
    }
    
    /// Auto layout self in superview
    ///
    /// - Parameters:
    ///   - view:           Super view of it.
    ///   - bView:          Align self's top to bView's bottom
    ///   -gap              Gap between self's top and bView's bottom
    func layoutInView(view:UIView,
                      belowView bView: UIView,
                      gap: CGFloat) {
    
        self.translatesAutoresizingMaskIntoConstraints = false
        let viewLeftConstraint = NSLayoutConstraint(item: self,
                                                    attribute: .leading,
                                                    relatedBy: NSLayoutConstraint.Relation.equal,
                                                    toItem: view,
                                                    attribute: .leading,
                                                    multiplier: 1,
                                                    constant: 0)
        let viewRightConstraint = NSLayoutConstraint(item: self,
                                                     attribute: .trailing,
                                                     relatedBy: NSLayoutConstraint.Relation.equal,
                                                     toItem: view,
                                                     attribute: .trailing,
                                                     multiplier: 1,
                                                     constant: 0)
        let viewTopConstraint = NSLayoutConstraint(item: self,
                                                   attribute: .top,
                                                   relatedBy: NSLayoutConstraint.Relation.equal,
                                                   toItem: bView,
                                                   attribute: .bottom,
                                                   multiplier: 1,
                                                   constant: gap)
        let viewBtmConstraint = NSLayoutConstraint(item: self,
                                                   attribute: .bottom,
                                                   relatedBy: NSLayoutConstraint.Relation.equal,
                                                   toItem: view,
                                                   attribute: .bottom,
                                                   multiplier: 1,
                                                   constant: gap)
        
        view .addConstraints([viewLeftConstraint,viewTopConstraint,viewRightConstraint,viewBtmConstraint])
        
    }
    
    /// Refresh cell from data source.
    ///
    /// - Parameters:
    ///   - index:           Index of cell to set.
    func refreshCellContent(atIndex index: Int) {
        let cell = self.cellForRow(at: IndexPath(row: index, section: 0)) as? ContactInfoTableCell
        if cell != nil && !( (cell?.isHidden)! ) {
            if self.dataSourceArray!.count > index {
                cell!.setContent(withContactModel: self.dataSourceArray![ index ] as! ContactModel)
            }
        }
    }
    
    // MARK - implements tableView DataSource
    /// Query cells number.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataSourceArray?.count ?? 0
    }
    
    /// Query table view cell at indexPath.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: REUSE_CELL_ID, for: indexPath) as! ContactInfoTableCell
        if self.dataSourceArray!.count > indexPath.row {
            cell.setContent(withContactModel: self.dataSourceArray![ indexPath.row ] as! ContactModel)
        }
        return cell
    }
    
    /// Query cell height at indexPath
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var cellSize = self.cellHeight;
        if cellSize < 1 {
            cellSize = self.bounds.size.height
        }
        self.snapHelper?.step = cellSize;
        return cellSize;
    }
    
    // MARK - implements scroll view delegate for snapHelper
    
    /// called on start of dragging (may require some time and or distance to move)
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewWillBeginDragging()
    }
    
    /// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        self.snapHelper?.mustInvokeInScrollViewWillEndDragging(velocity: velocity, targetContentOffset: targetContentOffset)
    }

    /// any offset changes
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewDidScroll()
    }
    
    /// called when scroll view grinds to a halt
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewDidEndDecelerating()
    }
    
    /// called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewDidEndDecelerating()
    }

}
