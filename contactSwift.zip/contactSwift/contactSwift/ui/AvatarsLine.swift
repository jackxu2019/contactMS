//
//  AvatarsLine.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// A row of Avatars, has snap function in scrolling.
/// There must be one cell stopped in the center of this row
/// And it can connect scrolling with other scroll view
class AvatarsLine: HorizontalLineCircularImageCellsView, ScrollSnapHelperDelegate {
    
    /// Image view to show the bottom shadow line.
    var decorateBtmLineImgView: UIImageView?
    
    /// Duration of some effect animation in this view.
    /// e.g. the bottom shadow line show and hide aniamation.
    var effectDuration: TimeInterval = 0.2
    
    /// If the bottom shadow line is showing.
    private(set) var isBtmLineShowing: Bool
    
    /// Creates a `AvatarsLine` instance with the specified parameters.
    ///
    /// - Parameters:
    ///   - circleR:                    Radius of cell,default is 35.
    ///   - selectedBorderThick         Border thick of selected ring,default is 4.
    override init(circleR: CGFloat = 35,
                  selectedBorderThick: CGFloat = 4) {
        self.isBtmLineShowing = false
        super.init(circleR: circleR)
        self.setStyles()
        self.createDecorateLineView()
    }
    
    /// Creates a `AvatarsLine` instance
    required init?(coder aDecoder: NSCoder) {
        self.isBtmLineShowing = false
        super.init(coder: aDecoder)
        self.circleR = 35
        selectedBorderThick = 4
        self.setStyles()
        self.createDecorateLineView()
    }
    
    /// Set default theme.
    func setStyles() {
        self.selectedBorderThick = 4
        self.selectedBorderColor = UIColor(red:196.0/255, green:224.0/255, blue:245.0/255, alpha:1.0)
        self.circleR = 35
        self.autoResizeImg = false
        self.autoCircularImg = false
        self.lineBgColor = UIColor.white
        self.cellSpacing = 21
        self.backgroundColor = UIColor.white
        self.insets = UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)
    }
    
    /// Show or hide the bottom shadow line .
    ///
    /// - Parameters:
    ///   - show:         show or hide.
    ///   - animated:     animate or not.
    func setCellImage(_ img: UIImage, atItemIndex index: Int) {
        let cell = self.cellAtIndex(index)
        if( cell != nil && !( cell!.isHidden ) ) {
            let imgView = cell!.cellContentView as! UIImageView
            imgView.image = img
        }
    }
    
    /// Show or hide the bottom shadow line .
    ///
    /// - Parameters:
    ///   - show:         show or hide.
    ///   - animated:     animate or not.
    func showBtmShadowLine(_ show: Bool, animated: Bool) {
        if show && self.isBtmLineShowing {
            return;
        }
        self.isBtmLineShowing = show;
        var opacity:CGFloat = 0.0;
        if( show ) {
        opacity = 1;
        }
        if animated {
            UIView.animate(withDuration: self.effectDuration) {
                [weak self] in
                self?.decorateBtmLineImgView?.layer.opacity = Float(opacity)
            }
        }
        else {
            self.decorateBtmLineImgView?.layer.opacity = Float(opacity)
        }
    }
    
    /// Create the image view as bottom shadow view.
    func createDecorateLineView() {
        self.decorateBtmLineImgView = UIImageView()
        self.decorateBtmLineImgView?.contentMode = .top
        self.addSubview(self.decorateBtmLineImgView!)
        let img = UIImage(named: "shadowLine")
        self.decorateBtmLineImgView?.image = img
        let cv = self.decorateBtmLineImgView
        let sv = self
        cv!.translatesAutoresizingMaskIntoConstraints = false
        let constraintH = NSLayoutConstraint.constraints(withVisualFormat:"H:|-0-[cv]-0-|",
                                                         options:[],
                                                         metrics:nil,
                                                         views:["cv":cv as Any])
        let constraintV = NSLayoutConstraint.constraints(withVisualFormat:"V:[sv]-0-[cv(==15)]",
                                                         options:[],
                                                         metrics:nil,
                                                         views:["cv":cv as Any, "sv":sv as Any])
        
        self.addConstraints(constraintH)
        self.addConstraints(constraintV)
        self.decorateBtmLineImgView?.layer.opacity = 0
    }
    
    /// layout view in superview
    ///
    /// - Parameters:
    ///   - view:         super view.
    func layoutInView(_ view: UIView) {
        let height:CGFloat = 128
        self.translatesAutoresizingMaskIntoConstraints = false
        
        let viewLeftConstraint = NSLayoutConstraint(item:self,
            attribute:NSLayoutConstraint.Attribute.leading,
            relatedBy:NSLayoutConstraint.Relation.equal,
            toItem:view,
            attribute:NSLayoutConstraint.Attribute.leading,
            multiplier:1,
            constant:0)
        let viewRightConstraint = NSLayoutConstraint(item:self,
                                                    attribute:NSLayoutConstraint.Attribute.trailing,
                                                    relatedBy:NSLayoutConstraint.Relation.equal,
                                                    toItem:view,
                                                    attribute:NSLayoutConstraint.Attribute.trailing,
                                                    multiplier:1,
                                                    constant:0)
        let viewTopConstraint = NSLayoutConstraint(item:self,
                                                     attribute:NSLayoutConstraint.Attribute.top,
                                                     relatedBy:NSLayoutConstraint.Relation.equal,
                                                     toItem:view,
                                                     attribute:NSLayoutConstraint.Attribute.top,
                                                     multiplier:1,
                                                     constant:0)
        let viewHeightConstraint = NSLayoutConstraint(item:self,
                                                   attribute:NSLayoutConstraint.Attribute.height,
                                                   relatedBy:NSLayoutConstraint.Relation.equal,
                                                   toItem:nil,
                                                   attribute:NSLayoutConstraint.Attribute.notAnAttribute,
                                                   multiplier:1,
                                                   constant:height)
        view.addConstraints([viewLeftConstraint,viewTopConstraint,viewRightConstraint,viewHeightConstraint])
    }
    
    // MARK: - implements HorizontalLineCellsView
    
    override func onSelectedCell(cell: HorizontalLineCell?, atIndex index: Int) {
        super.onSelectedCell(cell:cell, atIndex: index)
        self.selectItem(atIndex: index, animated: true, scrollPosition: .centeredHorizontally)
        self.snapHelper!.isScrollingByBindedHelper = true
        self.showBtmShadowLine(false, animated: false)
    }
    
    override func onCreateNewCell(cell: HorizontalLineCell, atIndex index: Int) {
        super.onCreateNewCell(cell: cell, atIndex:index)
        let imgView = cell.contentView as? UIImageView
        imgView?.backgroundColor = nil;
    }
    
    override func buildContents() {
        super.buildContents()
        self.snapHelper?.delegate = self
        self.setFirstCellCenterCanStopAtCenter()
        self.setLastCellCenterCanStopAtCenter()
    }
    
    // MARK: - implements ScrollSnapHelper

    func scrollSnapHelper(_ helper: ScrollSnapHelper, snapPositionReachedAtIndex index: Int) {
        if index >= 0 && index < self.cellsNumber {
            self.selectItem(atIndex: index,
                            animated: false,
                            scrollPosition: [])
        }
    }
    
    func scrollSnapHelper(_ helper: ScrollSnapHelper, beginScrollByOtherHelper otherHelper: ScrollSnapHelper) {
        self.showBtmShadowLine(true, animated: true)
    }

    func scrollSnapHelper(_ helper: ScrollSnapHelper, endedScrollByOtherHelper otherHelper: ScrollSnapHelper) {
        self.showBtmShadowLine(false, animated: true)
    }
    
    // MARK: - implements ScrollViewDelegate
    
    override func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        super.scrollViewWillBeginDragging(scrollView)
        self.snapHelper!.isScrollingByBindedHelper = false;
        self.showBtmShadowLine(false, animated:true)
    }
    
    override func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        super.scrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
        self.snapHelper!.isScrollingByBindedHelper = false
        self.showBtmShadowLine(false, animated:true)
    }
}

