//
//  ContactInfoTableCell.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Table view cell for ContactInfoTable
class ContactInfoTableCell: UITableViewCell {

    /// Label view for first name
    var firstNameLabel: UILabel?
    
    //// Label view for last name
    var lastNameLabel: UILabel?
    
    /// Label view for title
    var titleLabel: UILabel?
    
    /// Label view for introduction title
    var introTitleLabel: UILabel?
    
    /// Text view for introduction text
    var introTextView: UITextView?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.buildContent()
        // Initialization code
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.buildContent()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.buildContent()
    }
    
    /// The statue of selection be setted
    ///
    /// - Parameters:
    ///   - selected:           Is be selected
    ///   - animated:           If the selected cell should move.
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    /// Create and build subviews and auto layout them.
    func buildContent() {
        if self.firstNameLabel != nil {
            return
        }
        let topMargin:CGFloat = 5.0;
        let hMargin:CGFloat = 19;
        let firstNameFont = UIFont.systemFont(ofSize: 20, weight: .semibold)
        let lastNameFont = UIFont.systemFont(ofSize: 20, weight: .light)
        let textFont = UIFont.systemFont(ofSize: 14, weight: .light)
        let titleFont = UIFont.systemFont(ofSize: 14, weight: .semibold)
        let textColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
        let nameView = UIView()
        self.contentView.addSubview(nameView)
        self.firstNameLabel = UILabel()
        nameView.addSubview(self.firstNameLabel!)
        self.lastNameLabel = UILabel()
        nameView.addSubview(self.lastNameLabel!)
        
        let firstN = self.firstNameLabel
        let lastN = self.lastNameLabel
        self.translatesAutoresizingMaskIntoConstraints = false;
        firstN!.translatesAutoresizingMaskIntoConstraints = false;
        lastN!.translatesAutoresizingMaskIntoConstraints = false;
        nameView.translatesAutoresizingMaskIntoConstraints = false;
        let constraintH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[firstN]-5-[lastN]-0-|",
                                                         options: [],
                                                         metrics: nil,
                                                         views: ["firstN": firstN as Any, "lastN": lastN as Any])

        var constraintV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[firstN]-0-|",
                                                         options: NSLayoutConstraint.FormatOptions.alignAllCenterY,
                                                         metrics: nil,
                                                         views: ["firstN": firstN as Any])

        nameView.addConstraints(constraintH)
        nameView.addConstraints(constraintV)
        constraintV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[lastN]-0-|",
                                                     options: NSLayoutConstraint.FormatOptions.alignAllCenterY,
                                                     metrics: nil,
                                                     views: ["lastN": lastN as Any])

        nameView.addConstraints(constraintV)
        
        nameView.addConstraint(NSLayoutConstraint(item: nameView,
                                                  attribute: NSLayoutConstraint.Attribute.left,
                                                  relatedBy: NSLayoutConstraint.Relation.equal,
                                                  toItem: firstN,
                                                  attribute: NSLayoutConstraint.Attribute.left,
                                                  multiplier: 1,
                                                  constant: 0))
        nameView.addConstraint(NSLayoutConstraint(item: nameView,
                                                  attribute: NSLayoutConstraint.Attribute.right,
                                                  relatedBy: NSLayoutConstraint.Relation.equal,
                                                  toItem: lastN,
                                                  attribute: NSLayoutConstraint.Attribute.right,
                                                  multiplier: 1,
                                                  constant: 0))
        nameView.addConstraint(NSLayoutConstraint(item: nameView,
                                                  attribute: NSLayoutConstraint.Attribute.height,
                                                  relatedBy: NSLayoutConstraint.Relation.equal,
                                                  toItem: firstN,
                                                  attribute: NSLayoutConstraint.Attribute.height,
                                                  multiplier: 1,
                                                  constant: 0))

        self.contentView.addConstraint(NSLayoutConstraint(item: nameView,
                                                  attribute: NSLayoutConstraint.Attribute.top,
                                                  relatedBy: NSLayoutConstraint.Relation.equal,
                                                  toItem: self.contentView,
                                                  attribute: NSLayoutConstraint.Attribute.top,
                                                  multiplier: 1,
                                                  constant: topMargin))
        self.contentView.addConstraint(NSLayoutConstraint(item: nameView,
                                                          attribute: NSLayoutConstraint.Attribute.centerX,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.contentView,
                                                          attribute: NSLayoutConstraint.Attribute.centerX,
                                                          multiplier: 1,
                                                          constant: topMargin))
        self.titleLabel = UILabel()
        self.contentView.addSubview(self.titleLabel!)
        self.titleLabel!.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addConstraint(NSLayoutConstraint(item: self.titleLabel!,
                                                          attribute: NSLayoutConstraint.Attribute.centerX,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: nameView,
                                                          attribute: NSLayoutConstraint.Attribute.centerX,
                                                          multiplier: 1,
                                                          constant: 0))
        self.contentView.addConstraint(NSLayoutConstraint(item: self.titleLabel!,
                                                          attribute: NSLayoutConstraint.Attribute.top,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: nameView,
                                                          attribute: NSLayoutConstraint.Attribute.bottom,
                                                          multiplier: 1,
                                                          constant: 5))

        
        self.introTitleLabel = UILabel()
        self.contentView.addSubview(self.introTitleLabel!)
        self.introTitleLabel!.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTitleLabel!,
                                                          attribute: NSLayoutConstraint.Attribute.left,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.contentView,
                                                          attribute: NSLayoutConstraint.Attribute.left,
                                                          multiplier: 1,
                                                          constant: hMargin))
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTitleLabel!,
                                                          attribute: NSLayoutConstraint.Attribute.top,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.titleLabel,
                                                          attribute: NSLayoutConstraint.Attribute.bottom,
                                                          multiplier: 1,
                                                          constant: 33))
        
        self.introTextView = UITextView()
        self.contentView.addSubview(self.introTextView!)
        self.introTextView!.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTextView!,
                                                          attribute: NSLayoutConstraint.Attribute.left,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.contentView,
                                                          attribute: NSLayoutConstraint.Attribute.left,
                                                          multiplier: 1,
                                                          constant: hMargin))
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTextView!,
                                                          attribute: NSLayoutConstraint.Attribute.top,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.introTitleLabel,
                                                          attribute: NSLayoutConstraint.Attribute.bottom,
                                                          multiplier: 1,
                                                          constant: 5))
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTextView!,
                                                          attribute: NSLayoutConstraint.Attribute.trailing,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.contentView,
                                                          attribute: NSLayoutConstraint.Attribute.trailing,
                                                          multiplier: 1,
                                                          constant: -hMargin))
        self.contentView.addConstraint(NSLayoutConstraint(item: self.introTextView!,
                                                          attribute: NSLayoutConstraint.Attribute.bottom,
                                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                                          toItem: self.contentView,
                                                          attribute: NSLayoutConstraint.Attribute.bottom,
                                                          multiplier: 1,
                                                          constant: 0))
        
        firstN?.font = firstNameFont
        lastN?.font = lastNameFont
        firstN?.textColor = UIColor.black
        lastN?.textColor = UIColor.black
        self.titleLabel?.font = textFont
        self.titleLabel?.textColor = textColor
        self.introTitleLabel?.font = titleFont
        self.introTitleLabel?.textColor = UIColor.black
        self.introTextView?.font = textFont
        self.introTextView?.textColor = textColor
        self.introTextView?.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.introTextView?.textContainer.lineFragmentPadding = 0
        self.introTextView?.textContainerInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.introTextView?.isEditable = false
    }
    
    /// Set content text with contactModel
    ///
    /// - Parameters:
    ///   - contactModel:           contact model to present.
    func setContent(withContactModel contactModel: ContactModel) {
        
        self.firstNameLabel?.text = contactModel.first_name;
        self.lastNameLabel?.text = contactModel.last_name;
        self.titleLabel?.text = contactModel.title;
        self.introTitleLabel?.text = STR( "AboutMe" );
        self.introTextView?.text = contactModel.introduction;
        
    }
    


}
