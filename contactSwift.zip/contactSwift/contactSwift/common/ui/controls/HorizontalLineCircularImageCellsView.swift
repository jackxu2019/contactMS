//
//  HorizontalLineCircularImageCellsView.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Collection view with a row, has scrolling snap ability.
/// Every cell's content is a image view which can be setted circular, and
/// the decorator view has a ring style to present selection status.
/// Also implemented data source and cellection view delegate already.
/// It can be presented just by setting cells number.
/// There are two ways to set every cell's content(You can choose any one):
///   1: Extends this class and override the method: `onSettingCellViewContents(cellView:atIndex:)`.
///   2: Implements delegate of it.
class HorizontalLineCircularImageCellsView: HorizontalLineCellsView {
    
    /// Radius of the cell circle
    var circleR: CGFloat {
        set {
            self.cellSize = CGSize(width: newValue*2, height: newValue*2)
        }
        get {
            return self.cellSize.width / 2
        }
    }
    
    /// Border thick of selection ring decorator
    var selectedBorderThick: CGFloat
    
    /// Border color of selection ring decorator
    var selectedBorderColor: UIColor
    
    /// Auto resize the image to cell's size.Default is false.
    var autoResizeImg: Bool = false
    
    /// Auto circular the image view by auto setting layer's corner radius.Default is false.
    var autoCircularImg: Bool = false
    
    /// Creates a `HorizontalLineCircularImageCellsView` instance with the specified parameters.
    ///
    /// - Parameters:
    ///   - circleR:           Radius of the cell circle.
    ///   - cellSpacing        The spacing between cells,default is 3.
    init(circleR: CGFloat,
         selectedBorderThick: CGFloat = 4) {
        self.selectedBorderThick = selectedBorderThick
        self.selectedBorderColor = UIColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1)
        super.init(cellSize: CGSize(width: circleR*2, height: circleR*2))
        self.cellContentViewClass = UIImageView.self
        self.circleR = circleR
    }
    
    /// Creates a `HorizontalLineCircularImageCellsView` instance with the specified parameters.
    required init?(coder aDecoder: NSCoder) {
        self.selectedBorderThick = 4
        self.selectedBorderColor = UIColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1)
        super.init(coder: aDecoder)
        self.circleR = 10
        self.cellContentViewClass = UIImageView.self
    }

    /// Set the image view of content style
    private func setStyleOfImageView(imgView: UIImageView){
        if self.autoResizeImg {
            imgView.contentMode = .scaleToFill
        }else {
            imgView.contentMode = .center
        }
        if self.autoCircularImg {
            imgView.layer.cornerRadius = self.circleR;
            imgView.clipsToBounds = true;
        }
    }
    
    /// Set the ring shape layer's style.
    ///
    /// - Parameters:
    ///   - ringView:           The view to be setted.
    func setStyle(ofRingView ringView: CellRingView){
        ringView.ringShapeLayer.lineWidth = self.selectedBorderThick
        ringView.ringShapeLayer.strokeColor = self.selectedBorderColor.cgColor
        ringView.ringShapeLayer.fillColor = UIColor.clear.cgColor
    }
    
    // MARK: - override methods of HorizontalLineCellsView
    
    /// Callback method when need to set cell content.
    ///
    /// - Parameters:
    ///   - cellView:       The cell need to be setted.
    ///   - index:          The index of cell.
    override func onSettingCellViewContents(cellView: UIView?, atIndex index: Int) {
        super.onSettingCellViewContents(cellView: cellView, atIndex: index)
    }
    
    /// Callback method on selected a cell.
    ///
    /// - Parameters:
    ///   - cell:           The selected cell.
    ///   - index:          The index of cell.
    override func onSelectedCell(cell: HorizontalLineCell?, atIndex: Int) {
        super.onSelectedCell(cell: cell, atIndex: atIndex)
    }

    /// Callback method when created a new cell instance.
    ///
    /// - Parameters:
    ///   - cell:           The new created cell.
    ///   - index:          The index of cell.
    override func onCreateNewCell(cell: HorizontalLineCell, atIndex: Int) {
        super.onCreateNewCell(cell: cell, atIndex: atIndex)
        let imgView = cell.cellContentView as! UIImageView
        self.setStyleOfImageView(imgView: imgView)
        imgView.backgroundColor = UIColor.gray
        let ringView = CellRingView()
        ringView.buildContent(withR:self.circleR, andThick:0)
        UIView.installSubView(subView: ringView, fillSuperView:cell.decoratorView!)
        self.setStyle(ofRingView: ringView)
        cell.decoratorView!.isHidden = true
        cell.cellContentView!.backgroundColor = UIColor.clear
    }
    
    /// Callback method on setted the `isSelected` attribute of a cell.
    ///
    /// - Parameters:
    ///   - cell:           The setted cell.
    ///   - index:          The index of cell.
    override func onSetSelectedAttribute(ofCell cell: HorizontalLineCell?, isSelected: Bool) {
        cell?.decoratorView?.isHidden = !isSelected
    }
}

/// A colored ring shape view for presenting cell selected status
class CellRingView: UIView {
    
    /// Shape layer of the colored ring.
    private(set) var ringShapeLayer: CAShapeLayer
    
    /// Creates a `CellRingView` instance
    init() {
        self.ringShapeLayer = CAShapeLayer()
        super.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        self.layer.addSublayer(self.ringShapeLayer)
    }
    
    /// Creates a `CellRingView` instance with the specified parameters.
    required init?(coder aDecoder: NSCoder) {
        self.ringShapeLayer = CAShapeLayer()
        super.init(coder: aDecoder)
        self.layer.addSublayer(self.ringShapeLayer)
    }
    
    /// Build the ring shape
    ///
    /// - Parameters:
    ///   - r:              Radius of the ring shape.
    ///   - thick:          Thickness of the ring shape.
    func buildContent(withR r: CGFloat, andThick thick: CGFloat) {
        let radius = r + thick/2
        let rt = CGRect(x: -thick/2 ,y: -thick/2 ,width: radius*2, height: radius*2 )
        let path = CGPath( ellipseIn: rt , transform: nil );
        self.ringShapeLayer.path = path
    }
    
    
    
}
