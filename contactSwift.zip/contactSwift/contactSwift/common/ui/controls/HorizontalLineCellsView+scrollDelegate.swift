//
//  HorizontalLineCellsView+scrollDelegate.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import Foundation
import UIKit

/// extension to implements all the methods of UIScrollViewDelegate
extension HorizontalLineCellsView {
    
    /// called on start of dragging (may require some time and or distance to move)
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewDidScroll()
        if let delegate = self.delegate {
            delegate.scrollViewWillBeginDragging?(scrollView)
        }
    }
    
    /// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        self.snapHelper?.mustInvokeInScrollViewWillEndDragging(velocity: velocity,
                                                               targetContentOffset: targetContentOffset)
        if let delegate = self.delegate {
            delegate.scrollViewWillEndDragging?(scrollView,
                                               withVelocity: velocity,
                                               targetContentOffset: targetContentOffset)
        }
    }
    
    /// any offset changes
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.snapHelper?.mustInvokeInScrollViewDidScroll()
        self.onScrolling(scrollView: scrollView)
        if let delegate = self.delegate {
            delegate.scrollViewDidScroll?(scrollView)
        }
    }
    
    /// any zoom scale changes
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        if let delegate = self.delegate {
            delegate.scrollViewDidZoom?(scrollView)
        }
    }
    
    /// called on finger up if the user dragged. decelerate is true if it will continue moving afterwards
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if let delegate = self.delegate {
            delegate.scrollViewDidEndDragging?(scrollView, willDecelerate: decelerate)
        }
    }
    
    /// called on finger up as we are moving
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        if let delegate = self.delegate {
            delegate.scrollViewWillBeginDecelerating?(scrollView)
        }
    }
    
    /// called when scroll view grinds to a halt
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.snapHelper!.mustInvokeInScrollViewDidEndDecelerating()
        if let delegate = self.delegate {
            delegate.scrollViewDidEndDecelerating?(scrollView)
        }
    }
    
    /// called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        self.snapHelper!.mustInvokeInScrollViewDidEndDecelerating()
        if let delegate = self.delegate {
            delegate.scrollViewDidEndScrollingAnimation?(scrollView)
        }
    }
    

}
