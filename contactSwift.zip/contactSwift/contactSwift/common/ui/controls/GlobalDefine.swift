//
//  GlobalDefine.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/14.
//  Copyright © 2019 xu54. All rights reserved.
//

import Foundation
import UIKit

/// Convenient method of getting localized string.
///
/// - Parameters:
///   - str:            The string to be localized.
///   - Returns:        Localized string of str.
func STR(_ str: String) -> String {
    return NSLocalizedString(str, tableName: "localize", comment: "")
}

extension UIView {
    
    /// Add a subview and auto build constraints to fully fill the superview
    ///
    /// - Parameters:
    ///   - subView:            The sub view.
    ///   - superView:          The super view.
    public static func installSubView(subView:UIView, fillSuperView superView:UIView) -> Void {
        superView.addSubview(subView)
        subView.translatesAutoresizingMaskIntoConstraints = false
        let constraintH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[cv]-0-|", options: [], metrics: nil , views: ["cv":subView])
        let constraintV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[cv]-0-|", options: [], metrics: nil, views: ["cv":subView ])
        superView.addConstraints(constraintH)
        superView.addConstraints(constraintV)
    }
    
}
