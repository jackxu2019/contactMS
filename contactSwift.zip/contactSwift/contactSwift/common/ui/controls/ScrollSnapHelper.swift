//
//  ScrollSnapHelper.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/14.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

enum ScrollHelperDirection {
    case Horizontal
    case Vertical
}

/// Used to let any UIScrollView has snap function automatically.
/// Make any scroll view snap to integer multiple of the given step length.
/// When every snap occured, the delegate would be notified.
/// And the attached scroll view will always stop at the position of integer
/// multiple of the given step length.
/// It can also bind two scroll views to scroll synchronized at given rapid ratio.
class ScrollSnapHelper {
    /// The delegate of `ScrollSnapHelper`.
    weak var delegate: ScrollSnapHelperDelegate?
    
    /// The step length to snap.
    var step: CGFloat
    
    /// The tolerance of snap.
    var snapTolerance: CGFloat
    
    /// The minimize distance to scroll.
    var minDistanceToMove: CGFloat
    
    /// Attached scroll view.
    weak var scrollView: UIScrollView?
    
    /// The direction of scroll view to snap.
    var scrollDirection: ScrollHelperDirection
    
    /// Turn on or turn of snap effect
    var snapOn:Bool = true
    
    /// If current scrolling occured by another scroll view
    var isScrollingByBindedHelper:Bool = false
    
    // MARK: - Readonly Properties.
    
    /// The integer multiple of step currently scrolled.
    private(set) var snappedIndex: Int = 0
    
    /// The binded helper to make scrolling synchronized.
    private(set) var bindedHelper:ScrollSnapHelper?
    
    /// Position of last scrolling in the given direction.
    private(set) var lastScrollPosition: CGFloat = 0.0
    
    /// Ratio of scrolling rapid of the two binded scroll view.
    private(set) var bindedScrollRatio: CGFloat = 1.0
    
    // MARK: - Methods
    
    /// Creates a `ScrollSnapHelper` instance with the specified parameters.
    ///
    /// - Parameters:
    ///   - step:               The step length of scroll snapping.
    ///   - snapTolerance       The tolerance of snap.
    ///   - minDistanceToMove   The minimize distance to scroll.
    ///   - scrollDirection     The direction of scroll view to snap.
    init(step: CGFloat,
         snapTolerance: CGFloat = 27.0,
         minDistanceToMove: CGFloat = 20,
         scrollDirection: ScrollHelperDirection = .Horizontal) {
        self.step = step
        self.snapTolerance = snapTolerance
        self.minDistanceToMove = minDistanceToMove
        self.scrollDirection = scrollDirection
    }
    
    /// Attatch a scroll view to make it own snap function.
    ///
    /// - Parameters:
    ///   - scrollView:         The scroll view to attatch.
    func attachScrollView(_ scrollView: UIScrollView) -> Void {
        self.scrollView = scrollView
    }
    
    /// Detach the scroll view.
    func detachScrollView() {
        self.scrollView = nil
    }
    
    /// Bind with another `ScrollSnapHelper` to make two views scrolling synchronized.
    ///
    /// - Parameters:
    ///   - anotherHelper:          The other `ScrollSnapHelper` to bind.
    ///   - rapidRatioToOther:      The scroll rapid ratio to the other helper.
    ///   - isDualBind:             Is this a dual binding.
    func bindScroll(with anotherHelper: ScrollSnapHelper,
                    rapidRatioToOther: CGFloat,
                    isDualBind: Bool) -> Void {
        if abs( rapidRatioToOther ) < 0.0001 {
            return
        }
        self.bindedHelper = anotherHelper
        self.bindedScrollRatio = rapidRatioToOther
        if isDualBind {
            anotherHelper.bindScroll(with: self,
                                     rapidRatioToOther: 1/rapidRatioToOther,
                                     isDualBind: false)
        }
    }
    
    /// Unbind with another `ScrollSnapHelper`.
    ///
    /// - Parameters:
    ///   - isDualUnbind:             Is this a dual unbinding.
    func unbindScroll(isDualUnbind: Bool) -> Void {
        if isDualUnbind && self.bindedHelper != nil {
            self.bindedHelper?.unbindScroll(isDualUnbind: false)
        }
        self.bindedHelper = nil
    }
    
    /// Set total scrolled distance
    ///
    /// - Parameters:
    ///   - totalOffset:            Total scrolled distance.
    ///   - animated:               If animated to scroll the given offset.
    func scroll(totalOffset: CGFloat, animated: Bool) -> Void {
        if let scrollView = self.scrollView {
            var pt = scrollView.contentOffset
            if self.scrollDirection == .Horizontal {
                pt.x = totalOffset
            }else {
                pt.y = totalOffset
            }
            scrollView.setContentOffset(pt, animated: animated)
        }
    }
    
    /// Calculate if snap occured with the given scroll offset
    ///
    /// - Parameters:
    ///   - offset:             Total scrolled distance.
    ///   - returnIndex:        If snap occured, this is the the count of steps in offset
    ///   - Returns:            If snap occured.
    func snapIndex(withTotalOffset offset: CGFloat,
                   returnIndex: inout NSInteger) ->Bool {
        if self.step < 1 {
            return false
        }
        var index = -1
        let cellNumFloat: CGFloat = abs(offset / self.step)
        let cellNumInt = Int(cellNumFloat)
        let remainder: CGFloat = abs( offset ) - CGFloat(cellNumInt) * self.step
        var occured = false
        if remainder < self.snapTolerance {
            occured = true
            index = cellNumInt
        }else if self.step - remainder < self.snapTolerance {
            occured = true
            index = cellNumInt + 1;
        }
        if( occured ) {
            if offset < 0 {
                index = -index
            }
            returnIndex = index;
            return true;
        }
        return false;
    }
    
    /// Calculate the final offset when the scroll view stopped.
    ///
    /// - Parameters:
    ///   - offset:             Total scrolled distance.
    ///   - Returns:            Final offset when scroll stopped.
    func stopPosition(withTotalOffset offset: CGFloat) -> CGFloat {
        var resultOffset = offset;
        if self.step < 1 {
            return resultOffset
        }
        let cellNumFloat: CGFloat = abs( offset / self.step )
        let cellNumInt = Int(cellNumFloat)
        if cellNumFloat - CGFloat(cellNumInt) < 0.5 {
            resultOffset = CGFloat(cellNumInt) * self.step
        }else {
            resultOffset = CGFloat( cellNumInt + 1 ) * self.step
        }
        if offset < 0 {
            resultOffset = -resultOffset
        }
        return resultOffset
    }
    
    // MARK: - Scroll binding
    
    /// Access the scroll connection to binded helper.
    private func accessBindedHelperIfNeed() ->Void {
        if self.bindedHelper == nil {
            return
        }
        if self.isScrollingByBindedHelper {
            return
        }
        if abs(self.bindedScrollRatio) < 0.0001 {
            return
        }
        let bindedHelper = self.bindedHelper!
        if !bindedHelper.isScrollingByBindedHelper  {
            bindedHelper.isScrollingByBindedHelper = true
            if let otherDelegate = bindedHelper.delegate {
                otherDelegate.scrollSnapHelper(self, beginScrollByOtherHelper:bindedHelper)
            }
        }
        let scrollView = self.scrollView!
        var offset = scrollView.contentOffset.x
        if self.scrollDirection == .Vertical {
            offset = scrollView.contentOffset.y
        }
        let otherOffset = offset / self.bindedScrollRatio
        let otherScrollView = bindedHelper.scrollView!
        var newOffset = otherScrollView.contentOffset
        if bindedHelper.scrollDirection == .Horizontal {
            newOffset.x = otherOffset
        }else {
            newOffset.y = otherOffset
        }
        otherScrollView.setContentOffset(newOffset, animated:false)
    }
    
    // MARK: - Methods must be invoked in the scroll view delegate
    
    /// Must be invoked in `scrollViewWillBeginDragging` in scroll view's delegate
    func mustInvokeInScrollViewWillBeginDragging( ) -> Void {
        if let scrollView = self.scrollView {
            if !self.snapOn {
                return
            }
            if self.scrollDirection == .Horizontal {
                self.lastScrollPosition = scrollView.contentOffset.x
            }else {
                self.lastScrollPosition = scrollView.contentOffset.y
            }
        }
    }
    
    /// Must be invoked in `scrollViewWillEndDragging` in scroll view's delegate
    func mustInvokeInScrollViewWillEndDragging(velocity: CGPoint,
                                               targetContentOffset:  UnsafeMutablePointer<CGPoint>) ->Void {
        if self.scrollView == nil || !self.snapOn {
            return
        }
        let snapUnit = self.step
        if snapUnit < 0.01 {
            return
        }
        var v = velocity.x
        var currentOffset = targetContentOffset.pointee.x
        var newOffset: CGFloat = 0
        if self.scrollDirection == .Vertical {
            v = velocity.y;
            currentOffset = targetContentOffset.pointee.y
        }
        newOffset = currentOffset;
        //Very small velocity means that there's only drag-stop gesture without swipe.
        //That means the scroll view stopped as soon as user end dragging.
        var needCalculateNewOffset = true
        if abs(v) < 0.01 {
            let offset = currentOffset - self.lastScrollPosition
            if abs(offset) > self.minDistanceToMove && abs(offset) < snapUnit {
                newOffset = floor(abs(currentOffset) / snapUnit)*snapUnit
                if offset < 0 {
                    newOffset -= snapUnit
                }else {
                    newOffset += snapUnit
                }
                needCalculateNewOffset = false
            }
        }
        if needCalculateNewOffset {
            newOffset = ceil(abs(currentOffset) / snapUnit)*snapUnit;
            if currentOffset < 0 {
                newOffset = -newOffset
            }
        }
        newOffset = self.stopPosition(withTotalOffset: currentOffset)
        if self.scrollDirection == .Horizontal {
            targetContentOffset.pointee.x = newOffset
        }else {
            targetContentOffset.pointee.y = newOffset
        }
        self.lastScrollPosition = currentOffset
    }
    
    /// Must be invoked in `scrollViewDidScroll` in scroll view's delegate
    func mustInvokeInScrollViewDidScroll() -> Void {
        self.accessBindedHelperIfNeed()
        if !self.snapOn || self.scrollView == nil {
            return
        }
        if abs(self.step) < 1 {
            return
        }
        let scrollView = self.scrollView!
        var offset = scrollView.contentOffset.x
        if self.scrollDirection == .Vertical {
            offset = scrollView.contentOffset.y
        }
        var index = 0;
        let snapOccured = self.snapIndex(withTotalOffset: offset, returnIndex: &index)
        if snapOccured && index != self.snappedIndex {
            if let delegate = self.delegate {
                delegate.scrollSnapHelper(self, snapPositionReachedAtIndex:index)
            }
            self.snappedIndex = index;
        }
    }
    
    /// Must be invoked in `scrollViewDidEndDecelerating` in scroll view's delegate
    func mustInvokeInScrollViewDidEndDecelerating() -> Void {
        self.isScrollingByBindedHelper = false
        if let bindedHelper = self.bindedHelper {
            if bindedHelper.isScrollingByBindedHelper {
                if let bindedDelegate = bindedHelper.delegate {
                    bindedDelegate.scrollSnapHelper(self, endedScrollByOtherHelper:bindedHelper)
                }
                //Git rid of cumulative error
                let scrollTo = CGFloat(self.snappedIndex) * bindedHelper.step
                bindedHelper.scroll(totalOffset: scrollTo, animated: false)
            }
            bindedHelper.isScrollingByBindedHelper = false;
        }
    }

    
}

/// The delegate of `ScrollSnapHelper`
protocol ScrollSnapHelperDelegate : class {
    func scrollSnapHelper(_ helper: ScrollSnapHelper, snapPositionReachedAtIndex index: Int) -> Void
    func scrollSnapHelper(_ helper: ScrollSnapHelper, beginScrollByOtherHelper otherHelper: ScrollSnapHelper) -> Void
    func scrollSnapHelper(_ helper: ScrollSnapHelper, endedScrollByOtherHelper otherHelper: ScrollSnapHelper) -> Void
}
