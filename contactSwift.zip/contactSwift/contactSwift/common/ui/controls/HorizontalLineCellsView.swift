//
//  HorizontalLineCellsView.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Collection view with a row, has scrolling snap ability.
/// And implemented data source and cellection view delegate already.
/// It can be presented just by setting cells number.
/// There are two ways to set every cell's content(You can choose any one):
///   1: Extends this class and override the method: `onSettingCellViewContents(cellView:atIndex:)`.
///   2: Implements delegate of it.
class HorizontalLineCellsView: UIView, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    /// The delegate of `HorizontalLineCellsView`.
    weak var delegate: HorizontalLineCellsViewDelegate?
    
    /// The size of cell view.
    var cellSize: CGSize
    
    /// The spacing between cells.
    var cellSpacing: CGFloat
    
    /// The insets of view.
    var insets: UIEdgeInsets
    
    /// Turn on snap in scrolling.Default is true.
    var snapOn = true {
        didSet {
            let snapHelper: ScrollSnapHelper? = self.snapHelper
            if(snapHelper != nil) {
                self.snapHelper!.snapOn = snapOn
            }
        }
    }
    
    /// The meta class of cell's content view. If not be setted or nil, would use UIView as a content view.
    var cellContentViewClass: AnyClass
    
    /// The count of cells.
    var cellsNumber = 0
    
    /// If need a decorator view above the content view. Default is false.
    var cellHasDecoratorView = true
    
    /// If allows multiple selection of cells. Default is false.
    var allowsMultipleSelection = false
    
    /// Background color.
    var lineBgColor: UIColor? {
        get {
            return self.backgroundColor
        }
        set {
            self.backgroundColor = newValue
        }
    }
    
    /// Sub view which is a UICollectionView
    private(set) var collectionView: UICollectionView?
    
    /// Helper to access scroll snap and synchro scroll with other scroll view.
    private(set) var snapHelper: ScrollSnapHelper?
    
    static let cellReuseID = "cellRID"
    
    /// Creates a `HorizontalLineCellsView` instance with the specified parameters.
    ///
    /// - Parameters:
    ///   - cellSize:           Size of the cell view, default is (0,0).
    ///   - cellSpacing         The spacing between cells.
    init(cellSize: CGSize = CGSize(width: 0, height: 0),
         cellSpacing: CGFloat = 5
         ) {
        self.cellSize = cellSize
        self.cellSpacing = cellSpacing
        self.insets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.cellContentViewClass = UIView.self
        self.collectionView = nil
        self.snapHelper = nil
        super.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        self.lineBgColor = UIColor.white
    }
    
    /// Creates a `HorizontalLineCellsView` instance
    required init?(coder aDecoder: NSCoder) {
        self.cellSize = CGSize(width: 0, height: 0)
        self.cellSpacing = 5
        self.insets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.cellContentViewClass = UIView.self
        self.collectionView = nil
        self.snapHelper = nil
        super.init(coder: aDecoder)
        self.insets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.cellContentViewClass = type(of: UIView())
        self.lineBgColor = UIColor.white
    }
    
    /// Create and add a UICollectionView as subview.
    /// Note: Must set the size of the view before invoke this methods.
    /// And this method can be invoked only once.
    func buildContents() -> Void {
        self.layoutIfNeeded()
        // If the view's size not be setted, raise assertion failure.
        assert(self.bounds.size.width > 0.01 && self.bounds.size.height > 0.01, "Must setting frame size of HorizontalLineCellsView before buildSubViewsWithCellSize")
        // Make sure invoked only once.
        let collectionView: UICollectionView? = self.collectionView
        assert( collectionView == nil, "buildSubViewswithCellSize can be invoked only once")
        
        // Create collection view.
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = self.cellSpacing
        layout.minimumInteritemSpacing = self.cellSpacing
        layout.scrollDirection = .horizontal

        self.collectionView = UICollectionView(frame: self.bounds, collectionViewLayout: layout)
        self.collectionView!.showsHorizontalScrollIndicator = false
        self.addSubview(self.collectionView!)
        self.collectionView!.frame = self.bounds
        
        // Create snap helper.
        self.snapHelper = ScrollSnapHelper(step: self.cellSize.width + self.cellSpacing)
        self.snapHelper!.snapOn = self.snapOn
        self.snapHelper!.scrollView = self.collectionView
        self.collectionView!.dataSource = self
        self.collectionView!.delegate = self
        self.collectionView!.allowsMultipleSelection = self.allowsMultipleSelection;
        self.collectionView!.register(HorizontalLineCell.self, forCellWithReuseIdentifier: HorizontalLineCellsView.cellReuseID)
        self.collectionView!.backgroundColor = UIColor.clear
    }
    
    /// Select a cell by given index.
    ///
    /// - Parameters:
    ///   - index:          The index of cell to select.
    ///   - animated:       If the selection occurs scrolling animation.
    ///   - scrollPosition: The position of selected cell.
    func selectItem(atIndex index: Int,
                    animated: Bool,
                    scrollPosition: UICollectionView.ScrollPosition) -> Void {
        self.collectionView!.selectItem(at: IndexPath(item: index, section: 0),
                                   animated: animated,
                                   scrollPosition: scrollPosition)
    }
    
    /// Scroll to given offset
    ///
    /// - Parameters:
    ///   - offset:         Offset X of scroll.
    ///   - animated:       If scroll with animation.
    func scroll(offset: CGFloat, animated: Bool) -> Void {
        var contentOffset = self.collectionView!.contentOffset
        contentOffset.x += offset
        self.collectionView!.setContentOffset(contentOffset, animated: animated)
    }
    
    /// Set first cell's center can stop at X
    ///
    /// - Parameters:
    ///   - x:         Position X of first cell's center.
    func setFirstCellCenterCanStopAt(x: CGFloat) -> Void {
        self.insets.left = x - self.cellSize.width/2
    }
    
    /// Set last cell's center can stop at X
    ///
    /// - Parameters:
    ///   - x:         Position X of last cell's center.
    func setLastCellCenterCanStopAt(x: CGFloat) -> Void {
        self.insets.right = x - self.cellSize.width/2
    }
    
    /// Set first cell's center can stop at x center of current row.
    func setFirstCellCenterCanStopAtCenter() -> Void {
        self.setFirstCellCenterCanStopAt(x: self.bounds.size.width/2)
    }
    
    /// Set last cell's center can stop at x center of current row.
    func setLastCellCenterCanStopAtCenter() -> Void {
        self.setFirstCellCenterCanStopAt(x: self.bounds.size.width/2)
    }
    
    /// Get cell at index.
    ///  - Returns:     Cell at index, may be nil or hidden.
    func cellAtIndex(_ index: Int) -> HorizontalLineCell? {
        return  self.collectionView!.cellForItem(at: IndexPath(item: index, section: 0)) as? HorizontalLineCell
    }
    
    /// Force the collection view reload data.
    func reloadData() -> Void {
        self.collectionView!.reloadData()
    }
    
    // MARK: - Callback methods used for sub class to override
    
    /// Callback method when need to set cell content.
    ///
    /// - Parameters:
    ///   - cellView:       The cell need to be setted.
    ///   - index:          The index of cell.
    func onSettingCellViewContents(cellView: UIView?, atIndex index: Int) -> Void {
    }
    
    /// Callback method on selected a cell.
    ///
    /// - Parameters:
    ///   - cell:           The selected cell.
    ///   - index:          The index of cell.
    func onSelectedCell(cell: HorizontalLineCell?, atIndex: Int) -> Void {
    }
    
    /// Callback method when created a new cell instance.
    ///
    /// - Parameters:
    ///   - cell:           The new created cell.
    ///   - index:          The index of cell.
    func onCreateNewCell(cell: HorizontalLineCell, atIndex: Int) -> Void {
    }
    
    /// Callback method on setted the `isSelected` attribute of a cell.
    ///
    /// - Parameters:
    ///   - cell:           The setted cell.
    ///   - index:          The index of cell.
    func onSetSelectedAttribute(ofCell cell: HorizontalLineCell?, isSelected: Bool) -> Void {
    }
    
    /// Callback method on scrolling.
    ///
    /// - Parameters:
    ///   - scrollView:           The collection view.
    func onScrolling(scrollView: UIScrollView) -> Void {
    }
    
    // MARK: - Implements from UICollectionViewDataSource.
    
    /// Request the number of items by data source.
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.cellsNumber
    }

    /// Request a cell view by data source.
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: HorizontalLineCell = collectionView.dequeueReusableCell(withReuseIdentifier: HorizontalLineCellsView.cellReuseID, for: indexPath) as! HorizontalLineCell
        cell.lineContainerView = self
        if cell.cellContentView == nil {
            cell.createContentView(withMetaClass: self.cellContentViewClass)
            if self.cellHasDecoratorView {
                cell.createDecoratorView()
            }
            self.onCreateNewCell(cell: cell, atIndex: indexPath.item)
            if let delegate = self.delegate {
                delegate.horizontalLineCellsView?(sender: self, createdCell:cell, atIndex:indexPath.item)
            }
        }
        
        self.onSettingCellViewContents(cellView: cell.subviews[0], atIndex:indexPath.item)
        if let delegate = self.delegate {
            delegate.horizontalLineCellsView?(sender: self, setContentOfCell:cell, atIndex:indexPath.item)
        }
        return cell
    }
    
    // MARK: - Implements from UICollectionViewDelegateFlowLayout.
    /// Request the cell size by flow layout.
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return self.cellSize
    }

    /// Request the edge insets by flow layout.
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return self.insets
    }
    
    // MARK: - Implements from UICollectionViewDelegate.
    
    /// Did select a item by collection view delegate.
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? HorizontalLineCell {
        self.onSelectedCell(cell:cell, atIndex:indexPath.item)
        if let delegate = self.delegate {
            delegate.horizontalLineCellsView?(sender: self,
                                             selectedCell:cell,
                                             atIndex:indexPath.item,
                                             isByTap:true)
            }
        }
    }
    
    /// If current item can be selected.
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }

}

// MARK: - Delegate protocol

/// Protocol for delegate of HorizontalLineCellsView.
@objc protocol HorizontalLineCellsViewDelegate: UIScrollViewDelegate {
    
    /// Invoked when a new cell instance is created.
    ///
    /// - Parameters:
    ///   - sender:         The sender view.
    ///   - cell:           The new created cell.
    ///   - index:          The index of new cell.
    @objc optional func horizontalLineCellsView(sender: HorizontalLineCellsView,
                                 createdCell cell: HorizontalLineCell,
                                 atIndex index: Int)
    
    /// Invoked when setting the content of a cell
    ///
    /// - Parameters:
    ///   - sender:         The sender view.
    ///   - cell:           The cell which is being setted.
    ///   - index:          Index of the cell.
    @objc optional func horizontalLineCellsView(sender: HorizontalLineCellsView,
                                 setContentOfCell cell: HorizontalLineCell,
                                 atIndex index: Int)
    
    /// Invoked when a cell is selected.
    ///
    /// - Parameters:
    ///   - sender:         The sender view.
    ///   - cell:           The selected cell.
    ///   - index:          Index of the cell.
    @objc optional func horizontalLineCellsView(sender: HorizontalLineCellsView,
                                 selectedCell cell: HorizontalLineCell,
                                 atIndex index: Int,
                                 isByTap: Bool)

}
