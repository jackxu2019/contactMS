//
//  HorizontalLineCell.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Used as the cell view of `HorizontalLineCellsView`
class HorizontalLineCell: UICollectionViewCell {
    /// Cell's content view.
    var cellContentView: UIView?
    
    /// Decorator view covered on the content view.
    var decoratorView: UIView?
    
    /// Super view.
    weak var lineContainerView: HorizontalLineCellsView?
    
    /// override UIView
    override var isSelected: Bool {
        get {
            return super.isSelected
        }
        set {
            super.isSelected = newValue
            if let superView = lineContainerView {
                superView.onSetSelectedAttribute(ofCell: self, isSelected: newValue)
            }
        }
    }
    
    /// Create and add content view.
    ///
    /// - Parameters:
    ///   - mclass:         The meta class type to create content view.
    func createContentView(withMetaClass mclass: AnyClass?) -> Void {
        if let contentView = self.cellContentView {
            contentView.removeFromSuperview()
        }
        self.cellContentView = self.createSubView(withMetaClass: mclass)
    }
    
    /// Create and add decotrator view.
    func createDecoratorView() -> Void {
        if self.decoratorView != nil {
            return
        }
        self.decoratorView = self.createSubView(withMetaClass: UIView.self)
    }
    
    /// Create a new view and add as subview to contentView,and make it fill the super view.
    ///
    /// - Parameters:
    ///   - mclass:         The meta class type to create a new view.
    func createSubView(withMetaClass mclass: AnyClass?) -> UIView {
        let viewClass: UIView.Type = mclass as! UIView.Type
        let view: UIView = viewClass.init()
        UIView.installSubView(subView: view, fillSuperView: self.contentView)
        return view
    }
}
