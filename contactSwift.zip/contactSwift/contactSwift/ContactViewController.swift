//
//  ViewController.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/14.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// View Controller of Contact page
class ContactViewController: UIViewController, ContactEnginDelegate, HorizontalLineCellsViewDelegate {
 
    /// A row of Avatars
    var avatarsLine: AvatarsLine?
    
    /// Table view of contacts information.
    var infoTable: ContactInfoTable?
    
    /// Contruct and build subviews.
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = STR( "contactsNavTitle")
        self.avatarsLine = AvatarsLine()
        self.infoTable = ContactInfoTable()
        self.view.addSubview(self.infoTable!)
        self.view.addSubview(self.avatarsLine!)
        self.navigationController!.navigationBar.isTranslucent = false
        self.avatarsLine!.layoutInView(self.view)
        self.avatarsLine?.buildContents()
        self.avatarsLine!.delegate = self
        self.infoTable!.layoutInView(view: self.view, belowView: self.avatarsLine!, gap:0)
        self.infoTable!.layoutIfNeeded()
        self.infoTable!.cellHeight = self.infoTable!.bounds.size.height
        self.bindScrollOfAvatarsLineAndInfoTable()
        BusinessEngine.default.contact.delegate = self
        BusinessEngine.default.contact.loadAllContactsAsync()
        self.infoTable!.dataSourceArray = BusinessEngine.default.contact.contactsArray
    }

    /// Bind scrolling of AvatarLine and ContactInfoTable.
    /// Make them scroll asynchronized.
    func bindScrollOfAvatarsLineAndInfoTable() {
        let avatarLineSnapLen = self.avatarsLine?.snapHelper?.step
        self.infoTable?.layoutIfNeeded()
        let infoTableSnapLen = self.infoTable!.cellHeight
        if infoTableSnapLen < 0.01 {
            return
        }
        let snapRatio = avatarLineSnapLen! / infoTableSnapLen;
        avatarsLine?.snapHelper!.bindScroll(with:(self.infoTable?.snapHelper)!,
                                            rapidRatioToOther:snapRatio,
                                                isDualBind:true)
    }

    // MARK: - implements contactsEnginePart in BusinessEngine
    
    /// Called when received the count of contact items.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - count:          Count of contact items.
    func contactPartInEngine(contact: ContactPartInEngine, itemsCountReceived count: Int) {
        self.avatarsLine!.cellsNumber = count
        self.infoTable!.reloadData()
        self.avatarsLine?.reloadData()
        self.avatarsLine?.selectItem(atIndex: 0, animated: false, scrollPosition: [])
    }

    /// Called when received a contact item(not include image).
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - model:          Received contact model.
    ///   - index:          Index of the received item in contacts.
    func contactPartInEngine(contact: ContactPartInEngine, oneItemReceived model: ContactModel, atIndex index: Int) {
        self.infoTable?.refreshCellContent(atIndex: index)
    }

    /// Called when an avatar image is ready.
    ///
    /// - Parameters:
    ///   - contact:        Notification sender.
    ///   - img:            Image of an avatar.
    ///   - index:          Index of the item in contacts.
    func contactPartInEngine(contact: ContactPartInEngine, avatarImgIsReady img: UIImage?, atIndex index: Int) {
        self.avatarsLine?.setCellImage(img!, atItemIndex: index)
    }
    
    // MARK: - implements HorizontalLineCellsViewDelegate
    
    /// Invoked when setting the content of a cell
    ///
    /// - Parameters:
    ///   - sender:         The sender view.
    ///   - cell:           The cell which is being setted.
    ///   - index:          Index of the cell.
    func horizontalLineCellsView(sender: HorizontalLineCellsView, setContentOfCell cell: HorizontalLineCell, atIndex index: Int) {
        if BusinessEngine.default.contact.contactsArray.count > index {
            let cm = BusinessEngine.default.contact.contactsArray[ index ]
            let imgV =  cell.cellContentView as? UIImageView
            imgV!.image = (cm as! ContactModel).avatarImg
        }
    }

}

