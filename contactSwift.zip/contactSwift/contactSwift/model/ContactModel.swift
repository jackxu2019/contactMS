//
//  ContactModel.swift
//  contactSwift
//
//  Created by xu54 on 2019/1/16.
//  Copyright © 2019 xu54. All rights reserved.
//

import UIKit

/// Model class of contact info.
class ContactModel: NSObject {
    
    /// First name of contact
    var first_name: String?
    
    /// Last name of contact
    var last_name: String?
    
    /// Avatar image file name
    var avatar_filename: String?
    
    /// title of introduction
    var title: String?
    
    /// introduction of contact
    var introduction: String?
    
    ///avatar image
    var avatarImg: UIImage?
    
}
